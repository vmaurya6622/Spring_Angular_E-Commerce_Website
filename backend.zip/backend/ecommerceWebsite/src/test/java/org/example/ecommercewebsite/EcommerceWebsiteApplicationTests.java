package org.example.ecommercewebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceWebsiteApplicationTests {

    @Test
    void contextLoads() {
    }

}
